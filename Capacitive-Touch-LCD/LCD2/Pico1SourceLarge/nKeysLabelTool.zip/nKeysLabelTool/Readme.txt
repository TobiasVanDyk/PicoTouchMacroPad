Copy lbln lblp lblx to SDCard - you can use the pC App File Send - then rename the file1 to lbln, file2 to lblp, file3 to lblx
Switch to the nKeys = 'n' *0n*n and switch the labels on *0l*1. 
The nKeys should now display 144 names as label for keys n01 to n144.
Test for nKeys p and x. 
When you use nKey=N it uses the lbln file (SDCard not case sensitive) and after 144 keys it will display keys with number N145...

nKeys execute the filename inside the file that has the name of the nKey label
If custom labels is off then pressing nKey n01 will execute the filename found in file n01
If custom labels is on then pressing nKey n01 with the custom label Abby will execute the filename found in file Abby
There will be a flag added later to choose whether a custom label nKey should look for file n01 or Abby

As a test upload the files Abby, n01, s01 and U02 to the SDCard. Then press the nKey n01 with custom labels on and off and the nkey n01 should print either the contents of file S01 or U02

To convert JSON labels to Arduino char strings use the included ArduinoLabelTool.
Source Code included (ChatGPT) in the Serial2Pico folder on the Github TobiasVanDyk


